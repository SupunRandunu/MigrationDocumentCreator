# About Migration Documentation

To make sure that the upgrade process is smooth and you have the best experience, WSO2 recommends that you reach out to WSO2 Support when required in order to upgrade your WSO2 product with minimal difficulty.

WSO2 Support typically provides you with a .zip file that includes a guide that is in .md format along with associated migration resources that you can use at various points during the migration process.

> **Tip**
>
> Use an IDE of your choice to access the .md files that you receive for optimal viewing experience. For example, you can use VS Code or IntelliJ to preview this file.


The migration resources can be:

- DB Scripts - These are scripts that you have to run at various points against your database.

- Attachments - These include migration clients and other artifacts that you would need during the migration process.

> **Note**
>
> It is possible that you do not need the above reasources to upgrade some WSO2 products. 